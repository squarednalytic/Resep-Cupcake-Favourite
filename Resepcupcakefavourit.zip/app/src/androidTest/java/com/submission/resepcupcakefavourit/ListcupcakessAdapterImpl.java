package com.submission.resepcupcakefavourit;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class ListcupcakessAdapterImpl extends ListcupcakessAdapter {
    ListcupcakessAdapterImpl(ArrayList<cupcakeesData> list) {
        super(list);
    }

    @Override
    public void onBindViewHolder(@NonNull ListcupcakeAdapter.ListViewHolder holder, int position) {

    }
}
