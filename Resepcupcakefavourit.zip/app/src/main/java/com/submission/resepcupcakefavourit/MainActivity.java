package com.submission.resepcupcakefavourit;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.submission.resepcupcakefavourit.R;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String title = "Mode List";
    private RecyclerView rvCupcakes;
    private ArrayList<Cupcake> list = new ArrayList<>();
    private Bundle savedInstanceState;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        this.savedInstanceState = savedInstanceState;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setActionBarTitle(title);

        rvCupcakes = findViewById(R.id.rv_cupcakes);
        rvCupcakes.setHasFixedSize(true);

        list.addAll(cupcakesData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvCupcakes.setLayoutManager(new LinearLayoutManager(this));
        ListCupcakeAdapter listCupcakeAdapter = new ListCupcakeAdapter(list);
        rvCupcakes.setAdapter(listCupcakeAdapter);

        listCupcakeAdapter.setOnItemClickCallback(new ListCupcakeAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Cupcake data) {
                showSelectedCupcake(data);
            }
        });
    }

    private void showRecyclerGrid() {
        rvCupcakes.setLayoutManager(new GridLayoutManager(this, 2));
        GridCupcakeAdapter gridCupcakeAdapter = new GridCupcakeAdapter(list);
        rvCupcakes.setAdapter(gridCupcakeAdapter);

        gridCupcakeAdapter.setOnItemClickCallback(new GridCupcakeAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Cupcake data) {
                showSelectedCupcake(data);
            }
        });
    }

    private void showRecyclerCardView() {
        rvCupcakes.setLayoutManager(new LinearLayoutManager(this));
        CardViewCupcakeAdapter cardViewCupcakeAdapter = new CardViewCupcakeAdapter(list);
        rvCupcakes.setAdapter(cardViewCupcakeAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }

    public void setMode(int selectedMode) {
        switch (selectedMode) {
            case R.id.action_list:
                title = "Mode List";
                showRecyclerList();
                break;

            case R.id.action_grid:
                title = "Mode Grid";
                showRecyclerGrid();
                break;

            case R.id.action_cardview:
                title = "Mode CardView";
                showRecyclerCardView();
                break;
        }
        setActionBarTitle(title);
    }

    private void showRecyclerAbout() {
    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    private void showSelectedCupcake(Cupcake cupcake) {
        Toast.makeText(this, "Pilih resep : " + cupcake.getName(), Toast.LENGTH_SHORT).show();
    }
}

