package com.submission.resepcupcakefavourit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.text.Layout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class DetailActivity extends AppCompatActivity {

    ImageView img_detail_photo;
    TextView tv_detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        img_detail_photo = findViewById(R.id.img_item_photo);
        tv_detail = findViewById(R.id.tv_item_detail);

        Intent intent = getIntent();

        String name = intent.getStringExtra("NAMA");
        String detail = intent.getStringExtra("DETAIL");
        String photo = intent.getIntExtra("PHOTO");


        Glide.with(this)
                .load(photo)
                .apply(new RequestOptions())
                .into(img_detail_photo);

        tv_detail.setText(detail);


        if  (getSupportActionBar() !=null) {
            getSupportActionBar().setTitle(name);
        }
    }
}