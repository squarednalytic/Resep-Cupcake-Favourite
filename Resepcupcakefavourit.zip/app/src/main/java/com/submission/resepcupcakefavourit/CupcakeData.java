package com.submission.resepcupcakefavourit;

import com.submission.resecupcakepfavourit.R;

import java.util.ArrayList;

class cupcakesData {
    private static String[] cupcakesNames = {
            "Vanilla_cupcakes",
            "Rose_cupcake",
            "Cupcake_cokelat_kukus",
            "Triple_choco_cupcake",
            "Brownies_cup",
            "Super_moist_chocolate_cupcake",
            "Matcha_muffin",
            "Muffin_almond_choco_chips",
            "Eggless_cupcake",
            "Condensed_milk_cupcake"
    };

    private static String[] cupcakeDetails = {
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    private static int[] cupcakesImages = {
            R.drawable.vanilla_cupcakes,
            R.drawable.rose_cupcake,
            R.drawable.cupcake_cokelat_kukus,
            R.drawable.triple_choco_cupcake,
            R.drawable.brownies_cup,
            R.drawable.super_moist_chocolate_cupcake,
            R.drawable.matcha_muffin,
            R.drawable.muffin_almond_choco_chips,
            R.drawable.eggless_cupcake,
            R.drawable.condensed_milk_cupcake
    };

    static ArrayList<Cupcake> getListData() {
        ArrayList<Cupcake> list = new ArrayList<>();
        for (int position = 0; position < cupcakesNames.length; position++) {
            Cupcake cupcake = new Cupcake();
            cupcake.setName(cupcakesNames[position]);
            cupcake.setDetail(cupcakeDetails[position]);
            cupcake.setPhoto(cupcakesImages[position]);
            list.add(cupcake);
        }
        return list;
    }
}