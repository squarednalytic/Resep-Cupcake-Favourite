package com.submission.resepcupcakefavourit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;


public class AboutActivity extends AppCompatActivity {

    int img_about_photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        getSupportActionBar().setTitle("Made By:");

        img_about_photo = (R.drawable. about_me);
}
}
