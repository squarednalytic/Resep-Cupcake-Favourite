package com.submission.resepcupcakefavourit

class ListcupcakessAdapterTest extends groovy.util.GroovyTestCase {
    void testSetOnItemClickCallback() {
    }

    void testOnCreateViewHolder() {
    }

    void testOnBindViewHolder() {
    }

    void testGetItemCount() {
    }
}
